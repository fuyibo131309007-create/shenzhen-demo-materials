import math
from datetime import datetime
class MockService:
    def __init__(self):self.seen=set()
    def submit(self,payload,token='demo-token'):
        if token!='demo-token':return 401
        if not isinstance(payload,dict):return 400
        device=payload.get('device_id');v=payload.get('voltage');stamp=payload.get('sample_time')
        if not isinstance(device,str) or not 1<=len(device)<=32:return 400
        if isinstance(v,bool) or not isinstance(v,(int,float)) or not math.isfinite(v) or not 0<=v<=5:return 400
        if not isinstance(stamp,str) or len(stamp)!=25 or not stamp.endswith('+08:00'):return 400
        try:datetime.strptime(stamp,'%Y-%m-%dT%H:%M:%S%z')
        except ValueError:return 400
        key=(device,stamp)
        if key in self.seen:return 409
        self.seen.add(key);return 201
