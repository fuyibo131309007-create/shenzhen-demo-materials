import unittest
from mock_service import MockService
class ContractTest(unittest.TestCase):
    def setUp(self):self.s=MockService();self.p={'device_id':'d1','voltage':3.3,'sample_time':'2026-10-26T10:00:00+08:00'}
    def test_01_normal(self):self.assertEqual(self.s.submit(self.p),201)
    def test_02_zero(self):self.assertEqual(self.s.submit({**self.p,'voltage':0}),201)
    def test_03_maximum(self):self.assertEqual(self.s.submit({**self.p,'voltage':5}),201)
    def test_04_outside(self):self.assertEqual(self.s.submit({**self.p,'voltage':5.01}),400)
    def test_05_missing(self):p=dict(self.p);del p['voltage'];self.assertEqual(self.s.submit(p),400)
    def test_06_bool(self):self.assertEqual(self.s.submit({**self.p,'voltage':True}),400)
    def test_07_auth(self):self.assertEqual(self.s.submit(self.p,token=''),401)
    def test_08_duplicate(self):self.assertEqual(self.s.submit(self.p),201);self.assertEqual(self.s.submit(self.p),409)
    def test_09_invalid_date(self):self.assertEqual(self.s.submit({**self.p,'sample_time':'2026-02-30T10:00:00+08:00'}),400)
    def test_10_long_id(self):self.assertEqual(self.s.submit({**self.p,'device_id':'x'*33}),400)
    def test_11_nonfinite(self):self.assertEqual(self.s.submit({**self.p,'voltage':float('nan')}),400)
    def test_12_bad_time_shape(self):self.assertEqual(self.s.submit({**self.p,'sample_time':'2026-10-26T1:00:00+08:00'}),400)
if __name__=='__main__':unittest.main(verbosity=2)
