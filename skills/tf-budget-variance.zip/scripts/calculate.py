"""Portable deterministic demo calculations. Python 3.9+, stdlib only."""
import argparse,csv,json
from pathlib import Path
from decimal import Decimal, InvalidOperation
def number(x, name):
    if x is None or str(x).strip()=="": raise ValueError("缺少字段: "+name)
    try: d=Decimal(str(x))
    except InvalidOperation: raise ValueError("非数值: "+name)
    if not d.is_finite() or d<0: raise ValueError("要求非负有限数值: "+name)
    return d
def compute(mode, rows):
    result=[]; seen=set()
    for row in rows:
        key=row.get('费用ID') if mode=='budget' else row.get('部门') if mode=='workforce' else row.get('需求ID')
        if not key or key in seen: raise ValueError('ID缺失或重复: '+str(key))
        seen.add(key)
        if mode=='budget':
            b=number(row.get('预算元'),'预算元');a=number(row.get('实际元'),'实际元');d=a-b;rate=d/b if b else None
            result.append({**row,'偏差元':float(d),'偏差率':None if rate is None else float(rate),'状态':'超支' if d>0 else '节余' if d<0 else '持平','需归因':False if rate is None else abs(rate)>Decimal('.1'),'重点关注':False if rate is None else abs(rate)>=Decimal('.2'),'无预算发生费用':b==0 and a>0})
        elif mode=='workforce':
            n0=number(row.get('基期FTE'),'基期FTE');p0=number(row.get('基期平均全成本元'),'基期平均全成本元');n1=number(row.get('本期FTE'),'本期FTE');p1=number(row.get('本期平均全成本元'),'本期平均全成本元')
            c0=n0*p0;c1=n1*p1;q=(n1-n0)*p0;p=n1*(p1-p0)
            if q+p!=c1-c0: raise ArithmeticError('量价对账失败')
            result.append({**row,'基期成本元':float(c0),'本期成本元':float(c1),'总差额元':float(c1-c0),'数量影响元':float(q),'价格影响元':float(p)})
        else:
            reach=number(row.get('Reach人数'),'Reach人数');impact=number(row.get('Impact'),'Impact');conf=number(row.get('Confidence'),'Confidence');effort=number(row.get('Effort人周'),'Effort人周')
            if conf>1 or effort==0: raise ValueError('Confidence必须在0至1，Effort必须大于0')
            result.append({**row,'RICE':float(reach*impact*conf/effort)})
    if not result:raise ValueError('输入没有业务行')
    if mode=='rice':result.sort(key=lambda r:(-r['RICE'],r['需求ID']))
    return result
def main():
    parser=argparse.ArgumentParser();parser.add_argument('--input',required=True);parser.add_argument('--output',required=True);parser.add_argument('--mode',choices=['budget','workforce','rice'],required=True);a=parser.parse_args()
    with open(a.input,encoding='utf-8-sig',newline='') as f:rows=list(csv.DictReader(f))
    result=compute(a.mode,rows);target=Path(a.output);target.parent.mkdir(parents=True,exist_ok=True);target.write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n',encoding='utf8');print(json.dumps({'rows':len(result),'output':str(target)},ensure_ascii=False))
if __name__=='__main__': main()
